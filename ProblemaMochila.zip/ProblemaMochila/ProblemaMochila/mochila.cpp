#include <iostream>
#include <ilcplex/ilocplex.h>
#include <fstream>
#include <cstdio>
using namespace std;

#define MAXITEMS 10
#define MAXRECURSOS 10
int main() {
	//n = Quantidade de itens
	//k = Capacidade da mochila
	//lucro =  vetor com o valor dos objetos
	//pesos = vetor com o peso dos objetos

	int n, k;
	int lucro[MAXITEMS], pesos[MAXRECURSOS];
	int i;

	//Leitura dos dados da inst�ncia
	ifstream file("mochila.dat");

	file >> n;
	file >> k;

	for (int i = 0; i < MAXITEMS; i++) {
		file >> lucro[i];
		file >> pesos[i];

	}

	for (int i = 0; i < MAXITEMS; i++) {
		cout << pesos[i] << "\n";
	}

	try {
		//Declara��o do ambiente 
		IloEnv env;
		IloNumVarArray x(env, n, 0, 1, ILOBOOL);
		IloModel model(env);


		//Criar fun��o objetivo
		IloExpr funcaoObj(env);
		for (i = 0; i < n; i++) {
			funcaoObj = funcaoObj + (lucro[i] * x[i]);
		}
		model.add(IloMaximize(env, funcaoObj));
		funcaoObj.end();

		//Cria��o das restri��es
		IloExpr restr(env);
		for (i = 0; i < n; i++) {
			restr = restr + (pesos[i] * x[i]);
		}
		model.add(restr <= k);
		restr.end();

		bool status;
		IloCplex mycplex(model);
		IloNumArray sol(env);

		//Verificar solu��o
		status = mycplex.solve();
		if (status == true) {
			mycplex.getValues(sol, x);
			printf("Funcao objetivo(Solucao Otima) = %.2lf\n\n", mycplex.getObjValue());
			for (i = 0; i < n; i++) {
				printf("x%d = %.2lf\n", i, sol[i]);

			}

			//Apresentar os resultados
			mycplex.exportModel("SNDP.lp");
			mycplex.writeSolution("result.txt");
		}

		else {
			printf("Erro ao resolver!\n");
		}
		env.end();
	}
	catch (IloException& ex) {
		std::cout << "Erro: " << ex << std::endl;
	}

	system("pause");
	return 0;


}