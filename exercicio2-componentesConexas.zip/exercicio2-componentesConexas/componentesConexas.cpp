/* slide 25/26 da aula 3

Implemente o algoritmo abaixo apresentando como resultado um c�digo para o Graphviz onde cada componente conexa possua uma cor diferente

*/

#include <stdio.h>
#include <stdlib.h>

int qtdLinhas();
int n2;
void matrizAdjacencia ( int matrizAdj[][n2]);
void PROF (int v, int marca, int matrizAdj[][n2], int visitado[n2]);
void componentesConexas (int n2, int matrizAdj[][n2], int visitado[n2]);

// Lendo o arquivo do gr�fico para o graphviz
int qtdLinhas() {
	char ch;

	int num = 1;

	FILE* arq = fopen("componentesConexas-GraphViz1.txt", "r");

	if (arq == NULL) {
		printf ("Erro, nao foi possivel abrir o arquivo\n");
	}
	else {
		while ((ch = fgetc(arq)) != EOF) {
			if (ch == '\n') {
				num++;
			}
		}
	}
	return num;
	fclose(arq);
}

// Matriz de adjacencia
void matrizAdjacencia(int matrizAdj[][n2]) {
	int i, j;

	FILE* mat2 = fopen ("componentesConexas-GraphViz1.txt", "r");

	if (mat2 == NULL) {
		printf ("Nao foi poss�vel abrir o arquivo!");
	}
	else {
		while (!feof(mat2)) {
			for (i = 1; i <= n; i++) {
				for (j = 1; j <= n; j++) {
					fscanf (mat2, "%d", & matrizAdj[i][j]);
				}
			}
		}
	}
	fclose (mat2);

	printf ("Matriz de Adjacencia:\n");

	for (i = 1; i <= n; i++) {
		for (j = 1; j <= n; j++) {
			printf ("%2d ", matrizAdj[i][j]);
		}
		printf ("\n");
	}
}

// Pseudoc�digo das componentes conexas
void PROF (int v, int marca, int matrizAdj[][n2], int visitado[]) {
	int w;
	visitado[v] = marca;

	for (w = 1; w <= n; w++) {
		if (matrizAdj[v][w] == 1) {
			printf("%d %d\n", v, w);
			if (visitado[w] == 0) {
				PROF(w, marca, matrizAdj, visitado);
			}
		}
	}
}

void componentesConexas (int n2, int matrizAdj[][n2], int visitado[]) {
	int i, j;

	for (i = 1; i <= n; i++) {
		visitado[i] = 0;
	}

	int componente = 0;
	int vet[componente];

	for (i = 1; i <= n; i++) {
		if (visitado[i] == 0) {
			componente = componente + 1;
			printf("\n------\n");
			PROF(i, componente, matrizAdj, visitado);
			vet[componente] = componente;
		}
	}

	printf("\n\nQuantidade de componentes conexas: %d\n\n", componente);

	int numArestas = 0;
	for (i = 1; i <= n; i++) {
		for (j = 1; j <= n; j++) {
			if (matrizAdj[i][j] == 1) {
				numArestas = numArestas + 1;
			}
		}
	}

	int vet1[numArestas];
	int vet2[numArestas];
	int cont = 0;

	for (i = 1; i <= n; i++) {
		for (j = 1; j <= n; j++) {
			if (matrizAdj[i][j] == 1) {
				cont++;
				vet1[cont] = i;
				vet2[cont] = j;
			}
		}
	}

	int v;

	FILE* pont_arq;

	pont_arq = fopen ("GraphViz.txt", "w");

	if (pont_arq != NULL) {
		fprintf (pont_arq, "digraph G{\n");
		for (v = 1; v <= numArestas; v++) {
			fprintf (pont_arq, "%d -> %d\n", vet1[v], vet2[v]);
		}
		fprintf (pont_arq, "}");
	}
	else {
		printf ("O arquivo n�o foi aberto!\n");
	}

	fclose (pont_arq);
	printf ("\nDados gravados com sucesso!\n\n");
}

int main() {
	n2 = qtdLinhas();

	int matrizAdj[n2][n2];
	int visitado[n2];

	matrizAdjacencia(matrizAdj);

	componentesConexas (n2, matrizAdj, visitado);
	
	system("pause");
	return(0);
}



