/* Implementacao do minimax - figura 5.3 - capitulo 5 do livro Inteligencia Artificial - Russel e Norvig - 3a Ed. */

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#define MAX 10
#define MIN 20

struct estado
{
	int no_atual;
	int valor;
	int jogador;
};

// Estrutura para o no da arvore
struct bloco
{
	int pai;
	int no;
	int custo;
	struct bloco *proximo;
};

struct arvore
{
	struct bloco **lista;
};


// Criar lista de adjacencia do grafo
void criar_lista(struct arvore *adjacencia, int n)
{
	int i;
	adjacencia->lista = (struct bloco **)malloc(n*sizeof(struct bloco*));
	for(i = 0; i < n;i++)
	{
		adjacencia->lista[i] = NULL;

	}

}

// imprimir lista de adjacencia
void print_lista(struct bloco **lista, int n)
{
	int i,j, tam;
	struct bloco *aux;
	printf("n - %d\n",n);
	for(i = 0; i < n; i++)
	{
		
		aux = lista[i];
        //tam = tam_lista(aux);
		//printf("aux -> %d, tam -> %d\n",i, tam);
		while(aux != NULL)
		{
			printf("No -> %d, custo ->%d, pai-> %d ||", aux->no, aux->custo, aux->pai);
			aux = (struct bloco*)(aux->proximo);
		}
		printf("\n");
	}
}

// Inserir arestas na lista de adjacencia
void inserir_aresta(struct arvore *adjacencia, int pos, int no, int custo, int pai)
{
	struct bloco *node;
	node = (struct bloco*)malloc(sizeof(struct bloco));
	node->pai = pai;
	node->no = no;
	node->custo = custo;
	//printf("a - %d, b - %d, custo - %d, pai - %d \n",pos, node->no, node->custo, node->pai );

	node->proximo = (struct bloco *)adjacencia->lista[pos];
	adjacencia->lista[pos] = node;
	//printf("%p\n", adjacencia->lista[pos] );
}

int tam_lista(struct bloco *lista)
{
	int tam = 0;
	struct bloco *aux;
	aux = lista;
	while(aux != NULL)
	{
		tam = tam + 1;
		aux = aux->proximo;
	}
	return tam;
}

// Preencher um vetor com numeros iguais a n
int *preenche_vetor(int tam, int n)
{
	int i;
	int *v = (int *)malloc(tam*sizeof(int));
	for(i = 0;i < tam;i++)
		v[i] = n;
	return v;
}

int menor(int a, int b)
{
	if(a < b)
		return 1;
	return 0;
}

int maior(int a , int b)
{
	if(a > b)
		return 1;
	return 0;
}

// Funcao que retorna o maior valor 
int maximo(int a, int b)
{
	if(a > b)
		return a;
	return b;
}

// Funcao que retorna o menor valor 
int minimo(int a, int b)
{
	if(a < b)
		return a;
	return b;
}

// Funcao para verificar se ja esta nas folhas
int teste_terminal(struct arvore *adjacencia, int no_estado)
{
	int tam;
	tam = tam_lista(adjacencia->lista[no_estado]);
	if(tam == 1)
	{
		//printf("Teste\n");
		return 1;
	}
	return 0;
}

// Funcao para encontrar o pai do no
int encontrar_pai(struct arvore *adjacencia, int no)
{
	struct bloco *aux;
	aux = adjacencia->lista[no];
	// retornando o pai do no da arvore
	return aux->pai;
}

int valor_max(struct arvore *adjacencia, int no_estado, struct estado *estado_atual)
{
	int r, v, valor_aux, pai;
	struct bloco *aux;
	r = teste_terminal(adjacencia, no_estado);
	if(r == 1)
	{
		return adjacencia->lista[no_estado][0].custo;
	}
	//printf("Entrou VALOR MAX\n");
	v = INT_MIN;
	aux = adjacencia->lista[no_estado];
	aux = aux->proximo; // aux recebendo o bloco do primeiro vizinho
	while(aux != NULL)
	{ 
		valor_aux = valor_min(adjacencia, aux->no, estado_atual);
		if(maior(valor_aux, v))
		{
			v = valor_aux;
			if(estado_atual->jogador == MAX)
			{
				if(aux->pai == -2)
				{
					adjacencia->lista[0][0].custo = valor_aux;
				}
				else
				{
					pai = encontrar_pai(adjacencia, aux->no);
					adjacencia->lista[pai][0].custo = valor_aux;
					adjacencia->lista[aux->pai][0].custo = valor_aux;
				}
				estado_atual->no_atual = aux->no;
				estado_atual->valor = valor_aux;
				//printf("v-> %d NO-> %d aux-PAI -> %d PAI %d\n", v, aux->no, aux->pai, pai);
			}
		}
		
		aux = aux->proximo;
	}
	return v;
}

int valor_min(struct arvore *adjacencia, int no_estado, struct estado *estado_atual)
{
	int r, v, valor_aux, pai;
	struct bloco *aux;
	r = teste_terminal(adjacencia, no_estado);
	if(r == 1)
	{
		return adjacencia->lista[no_estado][0].custo;
	}
	//printf("Entrou VALOR MIN\n");
	v = INT_MAX;
	aux = adjacencia->lista[no_estado];
	aux = aux->proximo; // aux recebendo o bloco do primeiro vizinho
	while(aux != NULL)
	{ 
		valor_aux = valor_max(adjacencia, aux->no, estado_atual);
		if(menor(valor_aux, v))
		{
			v = valor_aux;
			if(estado_atual->jogador == MIN)
			{
				if(aux->pai == -2)
				{
					adjacencia->lista[0][0].custo = valor_aux;
				}
				else
				{
					pai = encontrar_pai(adjacencia, aux->no);
					adjacencia->lista[pai][0].custo = valor_aux;
					//adjacencia->lista[aux->pai][0].custo = valor_aux;
				}
				estado_atual->no_atual = aux->no;
				estado_atual->valor = valor_aux;
				//printf("v-> %d NO-> %d aux-PAI -> %d PAI %d\n", v, aux->no, aux->pai, pai);
			}			
		}
		
		aux = aux->proximo;
	}

	return v;
}

void imprimir_estado_atual(struct estado *estado_atual)
{
	printf("#### ESTADO ATUAL ####\n");
	if(estado_atual->jogador == MAX)
	{
		printf("Jogador: MAX\n");
	}
	else
		printf("Jogador: MIN\n");
	printf("Acao: Indo para o no %d\n", estado_atual->no_atual);
	printf("Valor: %d\n", estado_atual->valor);
}

void gerar_arvore_graphviz(struct arvore adjacencia, int n, char *arquivo)
{
	int i, j;
	struct bloco *aux;
	FILE *fd = fopen(arquivo, "w");
	fprintf(fd, "digraph {\n");
	for(i = 0; i < n; i++)
	{
		aux = adjacencia.lista[i];
		//aux = aux->proximo;
        //tam = tam_lista(aux);
		//printf("aux -> %d, tam -> %d\n",i, tam);
		while(aux != NULL)
		{
			// Colocar o valor numa aresta se for para ele mesmo
			if((aux->custo != 0) && (i == aux->no))
			{
				fprintf(fd, "\t %d -> %d [label = %d];\n", i, aux->no, aux->custo);
				//printf("\t %d -> %d [label = %d];\n", i, aux->no, aux->custo);
			}
			else 
				fprintf(fd, "\t %d -> %d;\n", i, aux->no);
			//printf("NO -> %d, custo ->%d, pai-> %d ||", aux->no, aux->custo, aux->pai);
			aux = (struct bloco*)(aux->proximo);
		}

		/*for (j = 0; j < matriz_adjacencia.n; j++)
		{
			if(matriz_adjacencia.matriz_custo[i][j] != 0)
			{
				fprintf(fd, "\t %d -> %d [label = %d];\n", i, j, matriz_adjacencia.matriz_custo[i][j]);
			}
		}*/
	}
	fprintf(fd, "}\n");
	fclose(fd);
}


int decisao_minimax(struct arvore *adjacencia, int no_estado, struct estado *estado_atual)
{
	int v, no_selecionado, tam;
	struct bloco *aux;
	if(estado_atual->jogador == MAX)
		v = valor_max(adjacencia, no_estado, estado_atual);
	else
		v = valor_min(adjacencia, no_estado, estado_atual);
	//imprimir_estado_atual(estado_atual);
	
	// Indo para o no da proxima jogada
	aux = adjacencia->lista[estado_atual->no_atual];
	tam = tam_lista(aux);
	//printf("Decicao minimax\n");
	while(tam != 1)
	{
		// Mudar para o proximo jogador
		if(estado_atual->jogador == MAX)
		{
			estado_atual->jogador = MIN;
			v = valor_min(adjacencia, estado_atual->no_atual, estado_atual);
		}
		else
		{
			estado_atual->jogador = MAX;
			v = valor_max(adjacencia, estado_atual->no_atual, estado_atual);
		}
		//printf("\n\n");
		//imprimir_estado_atual(estado_atual);
		aux = adjacencia->lista[estado_atual->no_atual];
		tam = tam_lista(aux);
	}
	return -1;

}


int main(int argc, char **argv)
{
	int i, j, n, arestas, a, b, custo, pai;
	char bi[500];
	int *nodes, *visitados, *arvore;
	struct arvore adjacencia;
	struct bloco *aux;
	struct estado estado_atual;

	//printf("Digite a quantidade de nos da arvore: \n");
	//scanf("%d %d", &n);
	//printf("Digite a quantidade de arestas:\n");
	//scanf("%d", &arestas);
	
	if(argc != 3)
	{
		printf("Execucao Invalida\n");
		printf("Exemplo: <%s> <arvore.tgf> <arquivo_saida_graphviz> \n", argv[0]);
		return 0;
	}

	FILE *fd = fopen(argv[1], "r");
	fscanf(fd, "%d %d", &n, &arestas);
	nodes = malloc(n*sizeof(int));
	for(i = 0; i < n; i++)
	{
		//printf("%d\n",i );
		fscanf(fd, "%d", &a);
		nodes[i] = a;
	}
	//printf("N - %d\n",n);
	criar_lista(&adjacencia, n);
	
    fscanf(fd,"%s",bi);

	for(i = 0; i < arestas; i++)
	{
		fscanf(fd, "%d %d %d %d", &a,&b,&custo,&pai);
		//printf("a - %d, b - %d, custo - %d, pai - %d \n",a, b, custo, pai );
		inserir_aresta(&adjacencia, (a - 1), (b - 1), custo, (pai - 1));

	}

	estado_atual.no_atual = 0;
	estado_atual.valor = 0;
	estado_atual.jogador = MAX;
	//print_lista(adjacencia.lista, n);
	a = decisao_minimax(&adjacencia, 0, &estado_atual);

	gerar_arvore_graphviz(adjacencia, n, argv[2]);
	
}
