/* Exercicio 2.8 - capitulo 2 do livro Inteligencia Artificial - Russel e Norvig - 3a Ed.

Questao 2.8 - Implemente um	simulador de ambiente de medicao de	desempenho para o mundo de aspirador de	po	
representado na	Figura 2.2 e especificado na pagina 38.	Sua	implementacao deve ser modular,	de	forma que os sensores,	os	atuadores
e	 as	 caracteristicas	 do	 ambiente	 (tamanho,	 forma,	 localizacao	 da	 sujeira	 etc.) possam	ser	alterados	com	facilidade. */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define DESLIGADO 0
#define LIGANDO 1
#define IR_ESQUERDA 2
#define IR_DIREITA 3
#define IR_BAIXO 4
#define IR_CIMA 5
#define ASPIRAR 6

struct ambiente
{
	int linhas;
	int colunas;
	int **matriz;
	int qtd_sujeira_inicial;
	int qtd_sujeira;
};

// Funcao para criar o ambiente com sujeira aleatoria com as informacoes passas pelo usuario
struct ambiente criar_ambiente_aleatorio(int linhas, int colunas)
{
	int i, j, r;
	struct ambiente casa;
	casa.linhas = linhas;
	casa. colunas = colunas;

	casa.matriz = (int **)malloc(linhas*sizeof(int *));

	for(i = 0; i < linhas; i++)
	{
		casa.matriz[i] = (int *)calloc(colunas, sizeof(int));
	}


	srand(time(NULL));
	casa.qtd_sujeira = 0;
	// Laco para preencher a quantidade de sujeira aleatoriamente
	for(i = 0; i < linhas; i++)
	{
		for(j = 0; j < colunas; j++)
		{
			// Sorteio para colocar sujeira sim(1) ou nao(0)
			r = rand()%2;
			if(r == 1)
			{
				casa.matriz[i][j] = 1;
				casa.qtd_sujeira += 1;
			}
		}
	}
	casa.qtd_sujeira_inicial = casa.qtd_sujeira;

	return casa;
}

// Criacao do ambiente totalmente sujo
struct ambiente criar_ambiente_totalmente_sujo(int linhas, int colunas)
{
	int i, j, r;
	struct ambiente casa;
	casa.linhas = linhas;
	casa. colunas = colunas;

	casa.matriz = (int **)malloc(linhas*sizeof(int *));

	for(i = 0; i < linhas; i++)
	{
		casa.matriz[i] = (int *)calloc(colunas, sizeof(int));
	}

	casa.qtd_sujeira = 0;
	for(i = 0; i < linhas; i++)
	{
		for(j = 0; j < colunas; j++)
		{
			casa.matriz[i][j] = 1;
			casa.qtd_sujeira += 1;
			
		}
	}
	casa.qtd_sujeira_inicial = casa.qtd_sujeira;
	return casa;
}

// Criacao do ambiente totalmente limpo
struct ambiente criar_ambiente_limpo(int linhas, int colunas)
{
	int i, j, r;
	struct ambiente casa;
	casa.linhas = linhas;
	casa. colunas = colunas;

	casa.matriz = (int **)malloc(linhas*sizeof(int *));

	for(i = 0; i < linhas; i++)
	{
		casa.matriz[i] = (int *)calloc(colunas, sizeof(int));
	}

	casa.qtd_sujeira = 0;
	casa.qtd_sujeira_inicial = casa.qtd_sujeira;
	return casa;
}

void imprime_matriz(int **matriz, int linhas, int colunas)
{
	int i,j;
	for(i = 0;i < linhas;i++)
	{
		for(j = 0; j < colunas; j++)
		{
			printf("%d ",matriz[i][j]);
		}
		printf("\n");
	}
}


float medir_desempenho(int qtd_sujeira_atual, int qtd_sujeira_inicial)
{
	float desempenho, resultado;

	// Quantidade em porcentagem que falta de sujeira;
	resultado = (qtd_sujeira_atual*100.0)/(float)qtd_sujeira_inicial;
	desempenho = 100 - resultado;
	printf("R-> %f e D -> %f\n", resultado, desempenho);
	return desempenho;
}

void imprimir_ambiente(struct ambiente *casa)
{
	int i, j, k, w;

	printf("------------------------- Ambiente ---------------------------\n");
	printf("Ambiente %d por %d\n", casa->linhas, casa->colunas);
	printf("Quantidade de sujeira: %d\n\n", casa->qtd_sujeira);
	for(w = 0; w < casa->colunas; w++)
	{
		printf("#######");
	}
	printf("\n");
	for(i = 0; i < casa->linhas; i++)
	{
		for(k = 0; k < 3; k++)
		{
			for(j = 0; j < casa->colunas; j++)
			{
				
				// Ambiente sujo sem o aspirador
				if((casa->matriz[i][j] == 1))
				{
					if(k == 0)
						printf("|     |");
					if(k == 1)
						printf("| *** |");
					if(k == 2)
						printf("|*****|");
					
				}
				
				// Ambiente limpo sem o aspirador
				else
				{
					
					if(k == 0)
						printf("|     |");
					if(k == 1)
						printf("|     |");
					if(k == 2)
						printf("|     |");
					
				}
				
			}
			printf("\n");
		}
		for(w = 0; w < casa->colunas; w++)
		{
			printf("#######");
		}
		printf("\n");

	}

}


int main(int argc, char **argv)
{
	int linhas, colunas, r;
	struct ambiente casa;

	printf("Digite a quantidade de linhas (X):");
	scanf("%d",&linhas);
	printf("Digite a quantidade de colunas (Y):");
	scanf("%d",&colunas);
	printf("Como deseja criar o ambiente?\n");
	printf("\t Digite 1 para criar o ambiente aleatoriamente.\n");
	printf("\t Digite 2 para criar o ambiente totalmente sujo.\n");
	printf("\t Digite 3 para criar o ambiente totalmente limpo.\n");
	scanf("%d", &r);
	if(r == 1)
		casa = criar_ambiente_aleatorio(linhas, colunas);
	else if(r == 2)
		casa = criar_ambiente_totalmente_sujo(linhas, colunas);
	else if(r == 3)
		casa = criar_ambiente_limpo(linhas, colunas);
	imprimir_ambiente(&casa);

	return 0;
}
