/* Exercicio 2.8 - cap�tulo 2 do livro Inteligencia Artificial - Russel e Norvig - 3a Ed. */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define DESLIGADO 0
#define LIGANDO 1
#define IR_ESQUERDA 2
#define IR_DIREITA 3
#define IR_BAIXO 4
#define IR_CIMA 5
#define ASPIRAR 6


// Estrutura para o agente aspirador de po
struct agente
{
	int x; // posicao x do aspirador no ambiente
	int y; // posicao y do aspirador no ambiente
	int custo; // custo gasto ate o momento da execucao
	int acao; // a area que ele esta operando
	float desempenho; // desempenho do aspirador
};

struct ambiente
{
	int linhas;
	int colunas;
	int **matriz;
	int qtd_sujeira_inicial;
	int qtd_sujeira;
};

// Funcao para criar o ambiente de acordo com as informacoes
// passadas pelo o usuario
struct ambiente criar_ambiente(int linhas, int colunas)
{
	int i, j, r;
	struct ambiente casa;
	casa.linhas = linhas;
	casa. colunas = colunas;

	casa.matriz = (int **)malloc(linhas*sizeof(int *));

	for(i = 0; i < linhas; i++)
	{
		casa.matriz[i] = (int *)calloc(colunas, sizeof(int));
	}


	srand(time(NULL));
	casa.qtd_sujeira = 0;
	// Laco para preencher a quantidade de sujeira aleatoriamente
	for(i = 0; i < linhas; i++)
	{
		for(j = 0; j < colunas; j++)
		{
			// Sorteio para colocar sujeira sim(1) ou nao(0)
			r = rand()%2;
			if(r == 1)
			{
				casa.matriz[i][j] = 1;
				casa.qtd_sujeira += 1;
			}
		}
	}
	casa.qtd_sujeira_inicial = casa.qtd_sujeira;

	return casa;
}

void imprime_matriz(int **matriz, int linhas, int colunas)
{
	int i,j;
	for(i = 0;i < linhas;i++)
	{
		for(j = 0; j < colunas; j++)
		{
			printf("%d ",matriz[i][j]);
		}
		printf("\n");
	}
}

char *operacao(int op)
{
	if(op == DESLIGADO)
	{
		return "Esta desligado.";
	}
	if(op == LIGANDO)
	{
		return "Ligando.";
	}
	if(op == IR_CIMA)
	{
		return "Indo para cima.";
	}
	if(op == IR_BAIXO)
	{
		return "Indo para baixo.";
	}
	if(op == IR_ESQUERDA)
	{
		return "Indo para esquerda.";
	}
	if(op == IR_DIREITA)
	{
		return "Indo para direita.";
	}
	if(op == ASPIRAR)
	{
		return "Limpando o local.";
	}
	return NULL;
}

float medir_desempenho(int qtd_sujeira_atual, int qtd_sujeira_inicial)
{
	float desempenho, resultado;

	// Quantidade em porcento que falta de sujeira;
	resultado = (qtd_sujeira_atual*100.0)/(float)qtd_sujeira_inicial;
	desempenho = 100 - resultado;
	printf("R-> %f e D -> %f\n", resultado, desempenho);
	return desempenho;
}

void imprimir_ambiente(struct ambiente *casa, struct agente *aspirador)
{
	int i, j, k, w;

	printf("------------------ Informacoes do Aspirador ------------------\n\n");
	printf("Posicao X: %d\n", aspirador->x);
	printf("Posicao y: %d\n", aspirador->y);
	printf("Acao: %s\n", operacao(aspirador->acao));
	printf("Custo Atual: %d\n", aspirador->custo);
	printf("Desempenho: %f\n\n",aspirador->desempenho);

	printf("------------------------- Ambiente ---------------------------\n\n");
	for(w = 0; w < casa->colunas; w++)
	{
		printf("#######");
	}
	printf("\n");
	for(i = 0; i < casa->linhas; i++)
	{
		for(k = 0; k < 3; k++)
		{
			for(j = 0; j < casa->colunas; j++)
			{
				// Ambiente sujo com o aspirador
				if((casa->matriz[i][j] == 1) && ((aspirador->x == i) && aspirador->y == j ))
				{
					if(k == 0)
						printf("| _A_ |");
					if(k == 1)
						printf("| *** |");
					if(k == 2)
						printf("|*****|");
				
				}
				// Ambiente sujo sem o aspirador
				else if((casa->matriz[i][j] == 1) && ((aspirador->x != i) || aspirador->y != j ))
				{
					if(k == 0)
						printf("|     |");
					if(k == 1)
						printf("| *** |");
					if(k == 2)
						printf("|*****|");
					
				}
				// Ambiente limpo com o aspirador
				else if((casa->matriz[i][j] == 0) && ((aspirador->x == i) && aspirador->y == j ))
				{
				
					if(k == 0)
						printf("|     |");
					if(k == 1)
						printf("| _A_ |");
					if(k == 2)
						printf("|     |");
					
				}
				// Ambiente limpo sem o aspirador
				else
				{
					
					if(k == 0)
						printf("|     |");
					if(k == 1)
						printf("|     |");
					if(k == 2)
						printf("|     |");
					
				}
				
			}
			printf("\n");
		}
		for(w = 0; w < casa->colunas; w++)
		{
			printf("#######");
		}
		printf("\n");

	}

}

void explorar_ambiente(struct ambiente *casa, struct agente *aspirador)
{
	int esquerda, direita, baixo;
	direita = 1;
	esquerda = 0;
	baixo = 0;
	//imprimir_ambiente(casa, aspirador);
	while(!((aspirador->x == casa->linhas-1) && (aspirador->y == casa->colunas -1)))
	{
		if(casa->matriz[aspirador->x][aspirador->y])
		{
			aspirador->acao = ASPIRAR;
			aspirador->custo += 1;
			casa->matriz[aspirador->x][aspirador->y] = 0;
			casa->qtd_sujeira -= 1;
			aspirador->desempenho = medir_desempenho(casa->qtd_sujeira, casa->qtd_sujeira_inicial);
		}
		else
		{
			if((casa->matriz[aspirador->x][aspirador->y] == 0) && (direita))
			{	
				aspirador->acao = IR_DIREITA;
				aspirador->custo += 1;
				aspirador->y += 1;
			}
			else if((casa->matriz[aspirador->x][aspirador->y] == 0) && (esquerda))
			{	
				aspirador->acao = IR_ESQUERDA;
				aspirador->custo += 1;
				aspirador->y -= 1;
			}
			else if((casa->matriz[aspirador->x][aspirador->y] == 0) && (baixo))
			{	
				aspirador->acao = IR_BAIXO;
				aspirador->custo += 1;
				aspirador->x += 1;
			}
			
		}
		imprimir_ambiente(casa, aspirador);
		if((aspirador->y == casa->colunas-1) && (direita) && (casa->matriz[aspirador->x][aspirador->y] == 0) )
		{
			//aspirador->y -= 1;
			printf("ENTROU A\n");
			direita = 0;
			esquerda = 0;
			baixo = 1;
		}
		// Verificando se tem mais de uma coluna para pode se mover para o lado
		else if((casa->colunas > 1) && (aspirador->y == casa->colunas-1) && baixo)
		{
			printf("ENTROU B\n");
			direita = 0;
			esquerda = 1;
			baixo = 0;
		}
		else if((aspirador->y == 0) && esquerda && (casa->matriz[aspirador->x][aspirador->y] == 0))
		{
			printf("ENTROU C\n");
			aspirador->y = 0;
			direita = 0;
			esquerda = 0;
			baixo = 1;
		}
		// Verificando se tem mais de uma coluna para pode se mover para o lado
		else if((casa->colunas > 1) && (aspirador->y == 0) && baixo )
		{
			printf("ENTROU D\n");
			direita = 1;
			esquerda = 0;
			baixo = 0;
		}

	}
	// A quantidade de linhas for par, tem que limpar a ultima linha
	if(casa->linhas % 2 == 0)
	{
		while(aspirador->y != 0)
		{
			if(casa->matriz[aspirador->x][aspirador->y])
			{
				aspirador->acao = ASPIRAR;
				aspirador->custo += 1;
				casa->matriz[aspirador->x][aspirador->y] = 0;
				casa->qtd_sujeira -= 1;
				aspirador->desempenho = medir_desempenho(casa->qtd_sujeira, casa->qtd_sujeira_inicial);
			}
			else
			{
				aspirador->acao = IR_ESQUERDA;
				aspirador->custo += 1;
				aspirador->y -= 1;
			}
			imprimir_ambiente(casa, aspirador);
		}
		if(casa->matriz[aspirador->x][aspirador->y])
		{
			aspirador->acao = ASPIRAR;
			aspirador->custo += 1;
			casa->matriz[aspirador->x][aspirador->y] = 0;
			casa->qtd_sujeira -= 1;
			aspirador->desempenho = medir_desempenho(casa->qtd_sujeira, casa->qtd_sujeira_inicial);
			imprimir_ambiente(casa, aspirador);
		}
	}
	if(casa->matriz[aspirador->x][aspirador->y])
	{
		aspirador->acao = ASPIRAR;
		aspirador->custo += 1;
		casa->matriz[aspirador->x][aspirador->y] = 0;
		casa->qtd_sujeira -= 1;
		aspirador->desempenho = medir_desempenho(casa->qtd_sujeira, casa->qtd_sujeira_inicial);
		imprimir_ambiente(casa, aspirador);
	}

}

void iniciando_agente(struct ambiente *casa, struct agente *aspirador)
{
	// Se o aspirador estiver no inicio do ambiente
	if((aspirador->x == 0) && (aspirador->y==0))
	{
		//if(aspirador->acao == LIGANDO)
		//	return;
		imprimir_ambiente(casa, aspirador);
		explorar_ambiente(casa, aspirador);
		return;
	}
	imprimir_ambiente(casa, aspirador);
	while(!((aspirador->x == 0) && (aspirador->y==0)))
	{
		if(casa->matriz[aspirador->x][aspirador->y])
		{
			aspirador->acao = ASPIRAR;
			aspirador->custo += 1;
			casa->matriz[aspirador->x][aspirador->y] = 0;
			casa->qtd_sujeira -= 1;
			aspirador->desempenho = medir_desempenho(casa->qtd_sujeira, casa->qtd_sujeira_inicial);
		}
		else if((aspirador->x > 0))
		{
			aspirador->acao = IR_CIMA;
			aspirador->custo += 1;
			aspirador->x -= 1;
		}
		else if((aspirador->x == 0) && (aspirador->y > 0))
		{
			aspirador->acao = IR_ESQUERDA;
			aspirador->custo += 1;
			aspirador->y -= 1;
		}
		imprimir_ambiente(casa, aspirador);
	}
	explorar_ambiente(casa, aspirador);
}

int main(int argc, char **argv)
{
	int linhas, colunas;
	int **ambiente;
	struct ambiente casa;
	struct agente aspirador;

	printf("Digite a quantidade de linhas (X):");
	scanf("%d",&linhas);
	printf("Digite a quantidade de colunas (Y):");
	scanf("%d",&colunas);

	casa = criar_ambiente(linhas, colunas);
	imprime_matriz(casa.matriz, casa.linhas, casa.colunas);

	printf("Digite a posicao X que o aspirador estara:");
	scanf("%d",&aspirador.x);
	printf("Digite a posicao Y que o aspirador estara:");
	scanf("%d",&aspirador.y);
	aspirador.acao = LIGANDO;
	aspirador.custo = 0;
	aspirador.desempenho = 0.0;

	//imprimir_ambiente(&casa, &aspirador);
	iniciando_agente(&casa, &aspirador);

	//printf("#######\n");
	//printf("|     |\n");
	//printf("|     |\n");
	//printf("|     |\n");
	//printf("#######\n");
	return 0;
}
