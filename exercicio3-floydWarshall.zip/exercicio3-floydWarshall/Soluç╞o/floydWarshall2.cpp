// Algoritmo de Floyd-Warshall em C
#include<stdio.h>
 
// Numero de vertices
#define V 4
 
// Defina Infinito como um valor grande o suficiente. Este valor ser� usado para vertices nao conectados um ao outro
#define INF 99999
 
// Funcao que imprime a matriz de solucao
void printSolution(int dist[][V]);
 
// Resolve o problema do caminho mais curto de todos os pares usando o algoritmo Floyd Warshall
void floydWarshall (int graph[][V])
{
    // dist[][] ser� a matriz de sa�da que finalmente ter� o mais curto dist�ncias entre cada par de v�rtices 
    int dist[V][V], i, j, k;
 
    // Inicializa a matriz da solu��o igual � matriz do grafico de entrada. 
	//Ou podemos dizer que os valores iniciais das dist�ncias mais curtas s�o baseados em caminhos mais curtos, considerando nenhum v�rtice intermedi�rio
    for (i = 0; i < V; i++)
        for (j = 0; j < V; j++)
            dist[i][j] = graph[i][j];
 
    /* Adiciona todos os v�rtices, um por um, ao conjunto de v�rtices intermedi�rios.
������---> Antes do in�cio de uma itera��o, temos dist�ncias mais curtas entre todos
������pares de v�rtices, de modo que as dist�ncias mais curtas considerem apenas
������v�rtices no conjunto {0, 1, 2, .. k-1} como v�rtices intermedi�rios.
������----> Ap�s o final de uma itera��o, o v�rtice n�o. k � adicionado ao conjunto de
������v�rtices intermedi�rios e o conjunto se torna {0, 1, 2, .. k}*/
    for (k = 0; k < V; k++)
    {
        // Escolha todos os v�rtices como fonte um por um
        for (i = 0; i < V; i++)
        {
            // Escolha todos os v�rtices como destino para a fonte acima escolhida
            for (j = 0; j < V; j++)
            {
                // Se o v�rtice k estiver no caminho mais curto de 
				// i para j, em seguida, atualize o valor de dist [i] [j]
                if (dist[i][k] + dist[k][j] < dist[i][j])
                    dist[i][j] = dist[i][k] + dist[k][j];
            }
        }
    }
 
    // Imprima a matriz de dist�ncia mais curta
    printSolution(dist);
}
 
/* Uma fun��o de utilidade para imprimir solu��o */
void printSolution(int dist[][V])
{
    printf ("A matriz a seguir mostra as dist�ncias mais curtas entre cada par de vertices \n");
    for (int i = 0; i < V; i++)
    {
        for (int j = 0; j < V; j++)
        {
            if (dist[i][j] == INF)
                printf("%7s", "INF");
            else
                printf ("%7d", dist[i][j]);
        }
        printf("\n");
    }
}
 
// Testa a fun��o acima
int main(){
    int graph[V][V] = { {0,   3,  INF, INF},
                        {INF, 0,  12, 5},
                        {4, INF, 0,   4},
                        {2, -4, INF, 0}
                      };
 
    // Imprima a solu��o
    floydWarshall(graph);
    return 0;
}
