#include<stdio.h>
#include<string.h>
#include<stdlib.h>

typedef struct integer{
        int valor;
        unsigned short int infinito;
}

num;
num grafo[100][100];
int x,no;

void getGrafo(){
    FILE *matriz;
    char tam[250], *token;
	matriz = fopen("matriz.txt", "r");
	no = 0;
	int col = 0;
	while( !feof(matriz)){
           
           fgets(tam, 255, matriz);
           token = strtok(tam , ",");
           col = 0;
	       while(token != NULL){
                       if(strcmp(token,"i") == 0 || strcmp(token,"i\n") == 0){
                            grafo[no][col].infinito = 1;
                       }
                       else{
                           grafo[no][col].infinito = 0;
                           grafo[no][col].valor = atoi(token);
                       }

                       token = strtok(NULL , ",");
                       col++;
           }
           no++;
    }    
}

void printGrafo(){
            for(int i=0; i<no; i++){
               for(int j=0; j<no; j++){
                       if(grafo[i][j].infinito == 1){
                          printf(" i");
                       }
                       else{
                           printf(" %d", grafo[i][j].valor);  
                       }
               } 
               printf("\n");    
            }
}

void floydWarshall(){
     int d1, d2, s;
     for(int k=0 ; k<no; k++){
             for(int i=0; i<no; i++){
                     for(int j=0; j<no; j++){
                             d1 = ((j != k) && (i != k)); 
                             if(d1){
                                   d2 = (grafo[i][k].infinito == 0) && (grafo[k][j].infinito == 0);
                                   if(d2){
                                         s = grafo[i][k].valor + grafo[k][j].valor;
                                         if (grafo[i][j].infinito == 1 || s < grafo[i][j].valor){
                                              grafo[i][j].valor = s;
                                              grafo[i][j].infinito = 0;
                                         }
                                   }
                             }   
                     }
             }
     printf("\n");
     printf("k = %d:\n",k+1);
     printGrafo();
     }
}

main()
{
      getGrafo();
      printGrafo();
      floydWarshall();
      scanf("%d",&x);
}
